package pis.presenter;

import java.util.List;
import pis.model.IQueries;
import pis.model.SingleMalt;
import pis.view.IView;

/**
 *
 * @author harshpreet
 */
public class SingleMaltPresenter {

    IView view;
    IQueries queries;
    List< SingleMalt> results;
    int currentEntryIndex;
    int numberOfEntries;
    SingleMalt currentEntry;
    int i = 0;
    String regexString;

    public SingleMaltPresenter(IView ipv, IQueries ipq) {
        view = ipv;
        queries = ipq;
        currentEntryIndex = 0;
        numberOfEntries = 0;
        results = null;
        currentEntry = null;
    }

    private void printResults() {

        view.setOutput("< " + currentEntry.getDistillery() + " , "
                + currentEntry.getAge() + " , "
                + currentEntry.getRegion() + " , "
                + currentEntry.getPrice() + " >  \n");

    }

    // handles call when clear button is clicked
    public void clearAll() {
        view.setDistilleryTextField("");
        view.setAgeTextField("");
        view.setRegionTextField("");
        view.setPriceTextField("");
        view.setMinAgeField("");
        view.setMaxAgeField("");
        view.setOutput("");

    }

    // handles call when Exit button is clicked
    public void Exit() {
        view.exitApplication("");

    }

    // handles call when All Malts button is clicked
    public void AllMalts() {
        view.setOutput("");
        try {

            results = queries.getAllMalts();

            numberOfEntries = results.size();
            if (numberOfEntries != 0) {

                for (int i = 0; i < numberOfEntries; i++) {

                    currentEntry = results.get(i);
                    printResults();

                } //end for

            }// end if
            else {
                view.setErrorMessage("");
                clearAll();
            }//end else
        } // end try // end try
        catch (Exception e) {
            e.printStackTrace();
        } // end catch

    }

    // handles call when Malts From Region button is clicked
    public void MaltsFromRegion() {

        view.setOutput("");
        if (view.getRegionTextField().isEmpty()) {
            view.setErrorMessage("Please Enter a Region!");
        } else {
            try {

                results = queries.getMaltsFromRegion(view.getRegionTextField());

                numberOfEntries = results.size();
                if (!results.isEmpty()) {
                    for (int i = 0; i < numberOfEntries; i++) {

                        currentEntry = results.get(i);

                        printResults();
                    }
                }// end if
                else {
                    view.setErrorMessage("Sorry! No Data Found!");
                    clearAll();

                }
            } // end try // end try
            catch (Exception e) {
                e.printStackTrace();
            } // end catch
        }

    }

    // handles call when Malts between age button is clicked

    public void MaltsInAge() {

        view.setOutput("");
        //show error if both min and max age fileds are empty
        if (view.getMinAgeTextField().isEmpty() && view.getMaxAgeTextField().isEmpty()) {
            clearAll();
            view.setErrorMessage("Please enter minimum or maximum age!");

        } //show error if only max field is empty
        else if (!view.getMinAgeTextField().isEmpty() && view.getMaxAgeTextField().isEmpty()) {
            regexString = "^[0-9]*$";

            if (view.getMinAgeTextField().toString().trim().matches(regexString)) {
                //it is digit

                view.setMaxAgeField("100");
                MaltsInAge();
            } else {
                //it is string

                view.setErrorMessage("Please enter an Integer!");
                view.setMinAgeField("");

            }

        } //show error if only min field is empty
        else if (view.getMinAgeTextField().isEmpty() && !view.getMaxAgeTextField().isEmpty()) {
            regexString = "^[0-9]*$";

            if (view.getMaxAgeTextField().trim().matches(regexString)) {
                //it is digit
                view.setMinAgeField("0");
                MaltsInAge();
            } else {
                //value is not an Integer
                view.setErrorMessage("Please enter an Integer!");
                view.setMaxAgeField("");

            }//end else

        } //if both inputs are correct set min and max to repective fields
        else if (!view.getMinAgeTextField().isEmpty() && !view.getMaxAgeTextField().isEmpty()) {
            regexString = "^[0-9]*$";

            if (view.getMinAgeTextField().trim().matches(regexString) && view.getMaxAgeTextField().trim().matches(regexString)) {
                //it is digit

                int minAge = Integer.parseInt(view.getMinAgeTextField());
                int maxAge = Integer.parseInt(view.getMaxAgeTextField());
                if (minAge > maxAge) {
                    view.setErrorMessage("maximum age cannot be smaller than minimum age!");
                    clearAll();

                } else {
                    try {

                        results = queries.numberOfMaltsWithinAgeRange(minAge, maxAge);

                        numberOfEntries = results.size();
                        if (!results.isEmpty()) {
                            for (int i = 0; i < numberOfEntries; i++) {

                                currentEntry = results.get(i);

                                printResults();
                            }
                        } else {
                            view.setErrorMessage("Sorry! No Data Found!");
                            clearAll();

                        }
                    } // end try // end try
                    catch (Exception e) {
                        e.printStackTrace();
                    } // end catch

                }
            } else {
                //it is string
                view.setErrorMessage("Please enter an Integer!");
                view.setMaxAgeField("");

            }//end else

        }//end elseif

    }// end MaltsInAge

    // handles call when Update malt button is clicked
    public void UpdateMalt() {

        view.setOutput("");

        if (view.getDistilleryTextField().isEmpty() && view.getAgeTextField().isEmpty() && view.getPriceTextField().isEmpty()) {
            clearAll();
            view.setErrorMessage("Please enter data in Distillery,Age and Price fields!");

        } else {
            try {

                regexString = "^[0-9]*$";
                if (!view.getDistilleryTextField().isEmpty() && view.getAgeTextField().trim().matches(regexString) && view.getPriceTextField().trim().matches(regexString)) {
                    int cAge = Integer.parseInt(view.getAgeTextField());
                    int cPrice = Integer.parseInt(view.getPriceTextField());
                    queries.changePriceForMalt(cPrice, view.getDistilleryTextField(), cAge);
                    if (queries.changePriceForMalt(cPrice, view.getDistilleryTextField(), cAge) >= 1) {

                        view.setOutput("");
                        AllMalts();
                        view.setOutput(" \n No of Malts Updated = " + queries.changePriceForMalt(cPrice, view.getDistilleryTextField(), cAge));

                    } else {
                        view.setErrorMessage("Sorry!Update Failed!");
                        clearAll();
                    }

                } else {
                    view.setErrorMessage("Please enter data in Distillery,Age and Price fields!");
                }

            } // end try
            catch (Exception e) {
                e.printStackTrace();
            } // end catch
        }// end else statemnet
    }// end updateMalt
} //end SingleMaltPresenter
