package pis;

/**
 *
 * @author harshpreet
 */
import pis.view.SingleMaltView;
import pis.presenter.SingleMaltPresenter;
import pis.model.SingleMaltQueries;

public class Products {

    public static void main(String[] args) {

        SingleMaltView sv = new SingleMaltView();

        SingleMaltQueries sq = new SingleMaltQueries();

        SingleMaltPresenter sp = new SingleMaltPresenter(sv, sq);

        sv.bind(sp);

    }

}
