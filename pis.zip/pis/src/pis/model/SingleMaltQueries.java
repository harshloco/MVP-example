
package pis.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author harshpreet
 */
public class SingleMaltQueries implements IQueries {

    private static final String URL = "jdbc:derby://localhost:1527/Products";
    private static final String USERNAME = "nbuser";
    private static final String PASSWORD = "nbuser";

    private Connection connection = null; // manages connection
    private PreparedStatement selectAllMalts = null;
    private PreparedStatement selectMaltsFromRegion = null;
    private PreparedStatement updatePriceForMalt = null;
    private PreparedStatement countMaltsWithinAgeRange = null;

    // constructor
    public SingleMaltQueries() {
        try {

            connection
                    = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            // create query that selects all entries in the SINGLEMALTS
            selectAllMalts
                    = connection.prepareStatement("SELECT * FROM SINGLEMALTS");
            // create query that selects all entries in the SINGLEMALTS where region matches the argument
            selectMaltsFromRegion
                    = connection.prepareStatement("SELECT * FROM SINGLEMALTS WHERE REGION = ?");
            // create query that selects all entries in the SINGLEMALTS where age range is specified
            countMaltsWithinAgeRange
                    = connection.prepareStatement("SELECT * FROM SINGLEMALTS WHERE AGE >= ? AND AGE <= ?");
            // update price for a specific malt
            updatePriceForMalt
                    = connection.prepareStatement("UPDATE SINGLEMALTS SET PRICE = ? WHERE DISTILLERY = ? AND AGE = ? ");

        } // end try // end try
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
            
            System.exit(1);
        } // end catch
    } // end SingleMaltQueries constructor

    // select all of the Malts in the database
    public List<SingleMalt> getAllMalts() {

        List< SingleMalt> results = null;
        ResultSet resultSet = null;

        try {

            // executeQuery returns ResultSet containing matching entries
            resultSet = selectAllMalts.executeQuery();
            results = new ArrayList< SingleMalt>();

            while (resultSet.next()) {
                results.add(new SingleMalt(
                        resultSet.getString("distillery"),
                        resultSet.getInt("age"),
                        resultSet.getString("region"),
                        resultSet.getInt("price")));

            } // end while

        } // end try
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } // end catch
        finally {
            try {
                resultSet.close();
            } // end try
            catch (SQLException sqlException) {
                sqlException.printStackTrace();
                close();
            } // end catch
        } // end finally
        if (results.size() != 0) {
            return results;
        } else {
            System.out.println("AllMalts Result is empty");
        }
        return results;
    } // end method getAllMalts

    // select all of the Malts from a sepcified region in the database
    public List<SingleMalt> getMaltsFromRegion(String region) {

        List< SingleMalt> results = null;
        ResultSet resultSet = null;

        try {

            selectMaltsFromRegion.setString(1, region); // specify region

            // executeQuery returns ResultSet containing matching entries
            resultSet = selectMaltsFromRegion.executeQuery();

            results = new ArrayList< SingleMalt>();

            while (resultSet.next()) {
                results.add(new SingleMalt(
                        resultSet.getString("distillery"),
                        resultSet.getInt("age"),
                        resultSet.getString("region"),
                        resultSet.getInt("price")));

            } // end while

        } // end try // end try
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } // end catch
        finally {
            try {
                resultSet.close();
            } // end try
            catch (SQLException sqlException) {
                sqlException.printStackTrace();
                close();
            } // end catch
        } // end finally
        if (results.size() != 0) {
            return results;
        } else {
            System.out.println("Malts from region result isempty");
        }
        return results;
    } // end method getmaltFromRegion

    // select all of the Malts from a sepcified age range in the database
    public List<SingleMalt> numberOfMaltsWithinAgeRange(int age1, int age2) {

        List< SingleMalt> results = null;
        ResultSet resultSet = null;

        try {

            countMaltsWithinAgeRange.setInt(1, age1); // specify region
            countMaltsWithinAgeRange.setInt(2, age2); // specify region

            // executeQuery returns ResultSet containing matching entries
            resultSet = countMaltsWithinAgeRange.executeQuery();

            results = new ArrayList< SingleMalt>();

            while (resultSet.next()) {
                results.add(new SingleMalt(
                        resultSet.getString("distillery"),
                        resultSet.getInt("age"),
                        resultSet.getString("region"),
                        resultSet.getInt("price")));

            } // end while

        } // end try // end try
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } // end catch
        finally {
            try {
                resultSet.close();
            } // end try
            catch (SQLException sqlException) {
                sqlException.printStackTrace();
                close();
            } // end catch
        } // end finally
        if (results.size() != 0) {
            return results;
        } else {
            System.out.println("Number of malts is empty");
        }
        return results;
    } // end method numberOfMaltsWithinAgeRange

    // update price of a sepcific record
    public int changePriceForMalt(int price, String distillery, int age) {

        int results = 0;
        try {

            updatePriceForMalt.setInt(1, price); // set input parameter 3
            updatePriceForMalt.setString(2, distillery); // set input parameter 1
            updatePriceForMalt.setInt(3, age); // set input parameter 2

            // executeQuery returns ResultSet containing matching entries
            results = updatePriceForMalt.executeUpdate();

        } // end try 
        catch (Exception exp) {
            System.out.println(exp.getMessage());
        } // end catch

        return results;
    } // end method numberOfMaltsWithinAgeRange
    // close the database connection

    //close database connection
    public void close() {
        try {
            connection.close();
        } // end try
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } // end catch
    } // end method close

} // end class SingleMaltQueries
