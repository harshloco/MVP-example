/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pis.model;

import java.util.List;

/**
 *
 * @author harshpreet
 */
public interface IQueries {

    List< SingleMalt> getAllMalts();

    List< SingleMalt> getMaltsFromRegion(String region);

    List<SingleMalt> numberOfMaltsWithinAgeRange(int age1, int age2);

    int changePriceForMalt(int price, String distillery, int age);

    void close();

}
