/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pis.model;

/**
 *
 * @author harshpreet
 */
public class SingleMalt {

    private String distillery;
    private int age; // input can only be a whole number
    private String region;
    private int price;  //input can only be a whole number 

   

    // constructor
    public SingleMalt(String d, int a, String r,
            int p) {

        setDistillery(d);
        setAge(a);
        setRegion(r);
        setPrice(p);

    } // end four-argument SIngleMalt constructor 

    //set the distillery
    private void setDistillery(String d) {

        distillery = d;
    }// end method setDistillery

    // returns the Distileery 
    public String getDistillery() {
        return distillery;
    } // end method getDistillery

    //set the age
    private void setAge(int a) {
        age = a;
    }// end method setAge

    // returns the Age
    public int getAge() {
        return age;
    } // end method getAge

    //set the region
    private void setRegion(String r) {
        region = r;
    }// end method setRegion

    // returns the region
    public String getRegion() {
        return region;
    } // end method getRegion

    //set the price
    private void setPrice(int p) {
        price = p;
    }// end method setPrice

    // returns the price
    public int getPrice() {
        return price;
    } // end method getPrice
    
    public String toString(){
        return ("List of Malts : \n" + "< " + distillery + " , "
                + age + " , "
                + region + " , "
                + price + " >  \n");
    }
}
