/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pis.view;

/**
 *
 * @author harshpreet
 */
public interface IView {

    public void setDistilleryTextField(String s);

    String getDistilleryTextField();

    public void setAgeTextField(String s);

    String getAgeTextField();

    public void setRegionTextField(String s);

    String getRegionTextField();

    public void setPriceTextField(String s);

    String getPriceTextField();

    public void setMinAgeField(String s);

    String getMinAgeTextField();

    public void setMaxAgeField(String s);

    String getMaxAgeTextField();

    public void setOutput(String s);

    public void exitApplication(String s);

    public void setErrorMessage(String s);
    
    String String();

}
