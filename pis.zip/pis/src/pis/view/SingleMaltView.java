package pis.view;

/**
 *
 * @author harshpreet
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import pis.presenter.SingleMaltPresenter;

public class SingleMaltView extends JFrame implements IView {

    // Variables declaration - do not modify                     
    private javax.swing.JButton button_allMalts;
    private javax.swing.JButton button_clear;
    private javax.swing.JButton button_exit;
    private javax.swing.JButton button_maltsFromRegion;
    private javax.swing.JButton button_maltsInAgeRange;
    private javax.swing.JButton button_updatePrice;
    private javax.swing.JTextField editText_Age;
    private javax.swing.JTextField editText_distillery;
    private javax.swing.JTextField editText_region;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel label_age;
    private javax.swing.JLabel label_ageRange;
    private javax.swing.JLabel label_distillery;
    private javax.swing.JLabel label_input;
    private javax.swing.JLabel label_output;
    private javax.swing.JLabel label_price;
    private javax.swing.JLabel label_queries;
    private javax.swing.JLabel label_region;
    private javax.swing.JTextField textField_maxAge;
    private javax.swing.JTextField textField_minAge;
    private javax.swing.JTextField textField_price;
    private SingleMaltPresenter presenter;
    // End of variables declaration 

    public SingleMaltView() {
        super("Restaurant Booking System");

        initComponents();

    }

    public void bind(SingleMaltPresenter pp) {
        presenter = pp;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        label_input = new javax.swing.JLabel();
        label_output = new javax.swing.JLabel();
        label_distillery = new javax.swing.JLabel();
        editText_distillery = new javax.swing.JTextField();
        label_age = new javax.swing.JLabel();
        editText_Age = new javax.swing.JTextField();
        label_region = new javax.swing.JLabel();
        editText_region = new javax.swing.JTextField();
        label_price = new javax.swing.JLabel();
        textField_price = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        label_ageRange = new javax.swing.JLabel();
        textField_minAge = new javax.swing.JTextField();
        textField_maxAge = new javax.swing.JTextField();
        label_queries = new javax.swing.JLabel();
        button_allMalts = new javax.swing.JButton();
        button_maltsFromRegion = new javax.swing.JButton();
        button_maltsInAgeRange = new javax.swing.JButton();
        button_updatePrice = new javax.swing.JButton();
        button_clear = new javax.swing.JButton();
        button_exit = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));

        label_input.setText("Input");

        label_output.setText("Output");

        label_distillery.setText("Distillery");

        editText_distillery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editText_distilleryActionPerformed(evt);
            }
        });

        label_age.setText("Age");

        editText_Age.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editText_AgeActionPerformed(evt);
            }
        });

        label_region.setText("Region");

        editText_region.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editText_regionActionPerformed(evt);
            }
        });

        label_price.setText("Price");

        textField_price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField_priceActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        label_ageRange.setText("Age Range");

        label_queries.setText("Queries");

        button_allMalts.setText("All Malts");
        button_allMalts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_allMaltsActionPerformed(evt);
            }
        });

        button_maltsFromRegion.setText("Malts from Region");
        button_maltsFromRegion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_maltsFromRegionActionPerformed(evt);
            }
        });

        button_maltsInAgeRange.setText("Malts in Age Range");
        button_maltsInAgeRange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_maltsInAgeRangeActionPerformed(evt);
            }
        });

        button_updatePrice.setText("Update Price");
        button_updatePrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_updatePriceActionPerformed(evt);
            }
        });

        button_clear.setText("Clear");
        button_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_clearActionPerformed(evt);
            }
        });

        button_exit.setText("Exit");
        button_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_exitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(label_input)
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                                        .addComponent(label_ageRange)
                                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                                                                        .addComponent(textField_minAge, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                                .addComponent(label_price)
                                                                                .addComponent(label_region, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(label_age, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(label_distillery))
                                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                                .addComponent(textField_price, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                                                                .addComponent(editText_region)
                                                                                .addComponent(editText_Age)
                                                                                .addComponent(editText_distillery))))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(textField_maxAge, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(26, 26, 26)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                        .addComponent(label_output)
                                                        .addGap(0, 263, Short.MAX_VALUE))
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)))
                                .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(button_maltsFromRegion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(button_allMalts, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(button_maltsInAgeRange, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(button_updatePrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(button_clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(button_exit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(layout.createSequentialGroup()
                                        .addComponent(label_queries)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                .addComponent(jSeparator2))
                        .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(51, 51, 51)
                                        .addComponent(label_output))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(label_input)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(label_distillery)
                                                .addComponent(editText_distillery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(editText_Age, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(label_age))
                                        .addGap(23, 23, 23)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(label_region)
                                                .addComponent(editText_region, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(21, 21, 21)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(label_price)
                                                .addComponent(textField_price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(25, 25, 25)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(label_ageRange)
                                                .addComponent(textField_minAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textField_maxAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(label_queries)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(button_allMalts)
                                .addComponent(button_updatePrice))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(button_clear)
                                .addComponent(button_maltsFromRegion))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(button_maltsInAgeRange)
                                .addComponent(button_exit))
                        .addGap(48, 48, 48))
        );

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }// </editor-fold>                        

    private void editText_distilleryActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void editText_AgeActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void editText_regionActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void textField_priceActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    @SuppressWarnings("empty-statement")
    private void button_allMaltsActionPerformed(java.awt.event.ActionEvent evt) {

        presenter.AllMalts();

    }

    private void button_maltsFromRegionActionPerformed(java.awt.event.ActionEvent evt) {

        presenter.MaltsFromRegion();

    }

    private void button_updatePriceActionPerformed(java.awt.event.ActionEvent evt) {

        presenter.UpdateMalt();

    }

    private void button_exitActionPerformed(java.awt.event.ActionEvent evt) {
        presenter.Exit();
    }

    private void button_clearActionPerformed(java.awt.event.ActionEvent evt) {
        presenter.clearAll();
    }

    private void button_maltsInAgeRangeActionPerformed(java.awt.event.ActionEvent evt) {

        presenter.MaltsInAge();

    }

    @Override
    public void setDistilleryTextField(String s) {
        editText_distillery.setText(s);
    }

    @Override
    public void setAgeTextField(String s) {
        editText_Age.setText(s);
    }

    @Override
    public void setRegionTextField(String s) {
        editText_region.setText(s);
    }

    @Override
    public void setPriceTextField(String s) {
        textField_price.setText(s);
    }

    @Override
    public String getDistilleryTextField() {
        return editText_distillery.getText();
    }

    @Override
    public String getAgeTextField() {
        return editText_Age.getText();
    }

    @Override
    public String getRegionTextField() {
        return editText_region.getText();
    }

    @Override
    public String getPriceTextField() {
        return textField_price.getText();
    }

    @Override
    public void setOutput(String s) {
        if ("".equals(s)) {
            jTextArea1.setText(s);
        } else {
            jTextArea1.append(s);
        }
    }

    @Override
    public void setMinAgeField(String s) {
        textField_minAge.setText(s);
    }

    @Override
    public String getMinAgeTextField() {
        return textField_minAge.getText();
    }

    @Override
    public void setMaxAgeField(String s) {
        textField_maxAge.setText(s);
    }

    @Override
    public String getMaxAgeTextField() {
        return textField_maxAge.getText();
    }

    @Override
    public void exitApplication(String s) {
        int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(this, "Do you want to Exit?", "Exit", dialogButton);
        if (dialogResult == 0) {
            dispose();
            System.exit(0);
        } else {
            //do nothing
        }
    }

    @Override
    public void setErrorMessage(String s) {
        JOptionPane.showMessageDialog(null, s);
    }

    @Override
    public java.lang.String String() {
        return ("List of Malts : \n");
    }

}
